#include <stdio.h>
#include <stdlib.h>

typedef struct{
	char nomeCliente[20];
	int acai;
	int tapioca;
}Pedido;

void main() {
	char nome[20];
	int op1, op2;
	
	printf("Ola como e o seu nome?\n");
	scanf("%c", &nome);
	
	printf("Deseja um acai? [1- 300ml, 2- 500ml, 3- 700ml, qualquer outro numero- Nao]\n");
	scanf("%d", &op1);
	
	printf("Deseja uma tapioca? [10- Frango, 20- Peito de peru, qualquer outro numero- Nao]\n");
	scanf("%d", &op2);
	
	printf("%s %d %d", nome, op1, op2);
}
